'use client'

import React, { useEffect, useState } from 'react'

type MenuItem = {
  label: string
  url: string
}

export default function Footer() {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([])

  useEffect(() => {
    fetch('https://cms.bidatlanticcars.com/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `
          {
            menu(id: "footer", idType: NAME) {
              menuItems {
                nodes {
                  label
                  url
                }
              }
            }
          }
        `,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        setMenuItems(data?.data?.menu?.menuItems?.nodes || [])
      })
  }, [])

  return (
    <footer className="bg-gray-900 text-white p-4 text-center">
      <div className="flex justify-center space-x-4">
        {menuItems.map((item, idx) => (
          <a key={idx} href={item.url} className="hover:underline">
            {item.label}
          </a>
        ))}
      </div>
      <div className="mt-4 text-sm text-gray-400">&copy; 2025 Bid Atlantic Cars</div>
    </footer>
  )
}
